package com.BankManagement.Controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.BankManagement.Model.Account;
import com.BankManagement.Service.AccountService;

@RestController
@RequestMapping("/accounts")
public class AccountController {
	 @Autowired
	    private AccountService accountService;

	    @PostMapping
	    @ResponseStatus(HttpStatus.CREATED)
	    public Account createAccount(@RequestBody Account account) {
	        return accountService.save(account);
	    }

	    @GetMapping
	    @ResponseStatus(HttpStatus.OK)
	    public List<Account> getAllAccount() {
	        return accountService.getAllAccounts();
	    }

	    @GetMapping("/{id}")
	    @ResponseStatus(HttpStatus.OK)
	    public Account getRoomById(@PathVariable Long id) {
	        return accountService.getAccountById(id);
	    }

	    @DeleteMapping("/{id}")
	    @ResponseStatus(HttpStatus.NO_CONTENT)
	    public void deleteAccount(@PathVariable Long id) {
	    	accountService.deleteAccount(id);
	    }

	    @PutMapping("/{id}")
	    @ResponseStatus(HttpStatus.OK)
	    public Account updateAccount(@PathVariable Long id, @RequestBody  Account account) {
	        return accountService.updateAccount(account);
	    }
	}



