package com.BankManagement.DTO;

import lombok.Data;
@Data
public class Principal
{
	 private String email;

	    private String token;

	    private String account;

		
}
