package com.BankManagement.ServiceImp;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.BankManagement.DTO.UserDTO;
import com.BankManagement.Exception.BadRequestExcpetion;
import com.BankManagement.Model.Account;
import com.BankManagement.Model.User;
import com.BankManagement.Respository.AccountRepository;
import com.BankManagement.Respository.UserRepository;
import com.BankManagement.Service.UserService;
import com.BankManagement.Util.JwtUtil;
import com.BankManagement.DTO.LoginDTO;



@Service
@Transactional
public class UserServiceImp implements UserService
{
	@Autowired
    private UserRepository userRepository;

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtUtil jwtUtil;

   // @Override
    @Override
	public void registerUser(UserDTO userDTO) {
       
		Optional<Account> optionalAccount = accountRepository.findByAccountNumber(userDTO.getAccountno());
        if(optionalAccount.isEmpty())
        {
           throw new BadRequestExcpetion("Select a valid role.");
        }

       User user=User.builder()
        				.name(userDTO.getName())
                  	.email(userDTO.getEmail())
                  	.phoneno(userDTO.getPhoneno())
                  	.accountno(userDTO.getAccountno())
                  	.password(passwordEncoder.encode
                      		(userDTO.getPassword()))
                  	.build();
          userRepository.save(user);
      }

    @Override
	public String login(LoginDTO loginDTO) {
        Optional<User> userOptional = userRepository.findByEmail(loginDTO.getEmail());
        if (userOptional.isEmpty()) {
            throw new BadRequestExcpetion("User not found");
        }
        User user = userOptional.get();
        if (passwordEncoder.matches(loginDTO.getPassword(), user.getPassword())) {
            return jwtUtil.generateAccessToken(user);
        } else {
            throw new BadRequestExcpetion("Invalid email or password");
        }
    }

}


