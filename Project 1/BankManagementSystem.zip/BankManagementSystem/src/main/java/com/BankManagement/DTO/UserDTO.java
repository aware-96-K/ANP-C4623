package com.BankManagement.DTO;

import lombok.Data;

@Data
public class UserDTO {
	private String name;

    private String email;

    private String password;
    
    private int accountno;
    
    private Long phoneno;
}





