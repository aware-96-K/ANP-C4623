package com.BankManagement.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Table(name = "account")
@Data
@Entity
public class Account
{
	@Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
    private int accountNumber;
    private int type;
    private double price;
    
  
}
