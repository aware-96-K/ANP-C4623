package com.BankManagement.DTO;

import lombok.Data;

@Data
public class AccountDTO {
	private Long id;
    private int accountNumber;
    private int type;
    private double price;
	
}
