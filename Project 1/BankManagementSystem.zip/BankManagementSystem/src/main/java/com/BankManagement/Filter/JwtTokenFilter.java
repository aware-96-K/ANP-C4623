package com.BankManagement.Filter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.BankManagement.DTO.JwtTokenDTO;
import com.BankManagement.DTO.Principal;
import com.BankManagement.Util.JwtUtil;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class JwtTokenFilter extends OncePerRequestFilter
{

	@Autowired
    private JwtUtil jwtUtil;

    @Override
    protected void
    	doFilterInternal(
        	HttpServletRequest request,
        	HttpServletResponse response,
			FilterChain filterChain
           ) throws ServletException, IOException
     {

    	final String header =
            	request.getHeader(HttpHeaders.AUTHORIZATION);

            if (header==null || !header.startsWith("Bearer ")) {
                filterChain.doFilter(request, response);
                return;
            }

            final String token = header.split(" ")[1].trim();
            if (!jwtUtil.validate(token)) {
                filterChain.doFilter(request, response);
                return;
            }

            JwtTokenDTO jwtTokenDTO=jwtUtil.getJwtTokenDTO(token);
            List<GrantedAuthority> grantedAuthorityList=
            	new ArrayList<>();

            grantedAuthorityList.add(
              new SimpleGrantedAuthority(jwtTokenDTO.getAccount()));

            Principal principal=new Principal();
            principal.setToken(token);
            principal.setEmail(jwtTokenDTO.getSubject());
            principal.setAccount(jwtTokenDTO.getAccount());

            UsernamePasswordAuthenticationToken authenticationToken=
    			new UsernamePasswordAuthenticationToken
                (principal,null,grantedAuthorityList);

            SecurityContextHolder.getContext()
            	.setAuthentication(authenticationToken);
            filterChain.doFilter(request,response);
        }
    }