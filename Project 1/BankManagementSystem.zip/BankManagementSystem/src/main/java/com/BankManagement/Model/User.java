package com.BankManagement.Model;



import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Table(name = "user")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity


public class User 
{
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String email;
    private String password;
    private int accountno;
    private Long phoneno;
    
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="account_id" ,referencedColumnName="id" )
    private Account account;
    
//    @ManyToOne(cascade=CascadeType.PERSIST)
//    private Booking booking;
}



