package com.BankManagement.Service;

import com.BankManagement.DTO.LoginDTO;
import com.BankManagement.DTO.UserDTO;

public interface UserService {
	void registerUser(UserDTO userDTO);
	  String login(LoginDTO loginDTO);
}
