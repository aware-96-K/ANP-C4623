package com.BankManagement.Service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.BankManagement.DTO.AccountDTO;
import com.BankManagement.Model.Account;

import com.BankManagement.Respository.AccountRepository;

	@Service
	public class AccountService
	{

	    @Autowired
	    private AccountRepository accountRepository;

	    public Account save(Account account)
	    {
	        return accountRepository.save(account);
	    }

	    public List<Account> getAllAccounts()
	    {
	        return accountRepository.findAll();
	    }

	    private Account convertToEntity(AccountDTO accountDTO)
	    {
	    	Account account = new Account();
	        // Set the properties of the room entity based on the roomDTO
	    	account.setAccountNumber(accountDTO.getAccountNumber());
	    	account.setType(accountDTO.getType());
	    	account.setPrice(accountDTO.getPrice());
	        // ... set other properties as needed

	        return account;
	    }

	    public Account addAccount(AccountDTO accountDTO)
	    {
	        // Convert AccountDTO to account entity
	    	Account account = convertToEntity(accountDTO);

	        // Save the account entity using the accountRepository
	        return accountRepository.save(account);
	    }

	    public Account getAccountById(Long id)
	    {
	        return accountRepository.findById(id)
	                .orElseThrow(() -> new RuntimeException("Account not found for id: " + id));
	    }

	    public Account updateAccount(Account account)
	    {
	        return accountRepository.save(account);
	    }

	    public void deleteAccount(Long id)
	    {
	    	accountRepository.deleteById(id);
	    }
	}